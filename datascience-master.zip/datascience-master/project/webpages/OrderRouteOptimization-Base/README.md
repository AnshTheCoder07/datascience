# Django and Charts.js
Learn how to integrate Charts.js with Django.