import pandas as pd
import os

files=[file for file in os.listdir('E:\CODING\project\csv_files')]
for file in files:
    print(file)
